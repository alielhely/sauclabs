package com.saucelabs.challenge;

import com.saucelabs.challenge.urlChecking.UrlListener;
import com.saucelabs.challenge.urlHandling.MagnificentUrlInvoker;
import com.saucelabs.challenge.urlHandling.UrlInvokerInterface;

/**
 * Hello world!
 *
 */
public class App {
	private static final String PYTHON_HOST = "http://localhost:12345";

	public static void main(String[] args) {
		UrlInvokerInterface urlInvoker = new MagnificentUrlInvoker();
		UrlListener.startListening(urlInvoker, PYTHON_HOST);
	}
}
