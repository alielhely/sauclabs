package com.saucelabs.challenge.logger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class LogWriter implements LogWriterInterface {

	final String newline = System.getProperty("line.separator");

	private String path = null;

	protected LogWriter(String pathString) {
		this.path = pathString;
	}

	public void log(String logLine) {
		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(path, true));
			writer.append(logLine + newline);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
