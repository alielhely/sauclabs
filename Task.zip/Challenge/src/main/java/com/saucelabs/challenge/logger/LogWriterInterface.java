package com.saucelabs.challenge.logger;

public interface LogWriterInterface {

	public void log(String logLine);

}
