package com.saucelabs.challenge.logger;

public class LoggerFactory {

	public LogWriterInterface getLogger(String path) {
		LogWriterInterface logWriter = new LogWriter(path);
		return logWriter;
	}

}
