package com.saucelabs.challenge.urlChecking;

import java.io.IOException;

import com.saucelabs.challenge.logger.LogWriterInterface;
import com.saucelabs.challenge.logger.LoggerFactory;
import com.saucelabs.challenge.urlHandling.UrlInvokerInterface;
import com.saucelabs.challenge.util.PropertiesHandler;

public class UrlListener implements UrlListenerInterface {

	private static final String SERVER_SUCCESS_RESPONSE = "Magnificent!";

	final int SLEEP_INTERVAL = 1000;

	final int ITERATIONS_COUNT = 10;

	private int count = 0;

	private int failedCount = 0;

	private int successCount = 0;

	private UrlInvokerInterface urlInvoker = null;

	private LogWriterInterface logWriter = null;

	private String url = null;

	protected UrlListener(UrlInvokerInterface urlInvokerObj, String urlString) {
		this.urlInvoker = urlInvokerObj;
		this.url = urlString;
		try {
			this.logWriter = new LoggerFactory().getLogger(PropertiesHandler.getPropertyValue("logFilePath"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void run() {
		while (true) {
			process();
		}

	}

	public static void startListening(UrlInvokerInterface urlInvokerObj, String urlString) {
		Thread urlListenerThread = new Thread(new UrlListener(urlInvokerObj, urlString));
		urlListenerThread.start();
	}

	public void process() {
		if (count == ITERATIONS_COUNT) {
			int health = (int) (((float) successCount / count) * 100);
			if (successCount > 0)
				this.logWriter.log("System health is " + health + "% with " + successCount
						+ " successful responses and " + failedCount + " failed counts.");
			else
				this.logWriter.log("System didnot respond at all");
			count = 0;
			failedCount = 0;
			successCount = 0;
		}
		count++;
		String response = urlInvoker.getResponse(this.url);
		if (response.equals(SERVER_SUCCESS_RESPONSE)) {
			successCount++;
		} else {
			failedCount++;
		}
		try {
			Thread.sleep(SLEEP_INTERVAL);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
