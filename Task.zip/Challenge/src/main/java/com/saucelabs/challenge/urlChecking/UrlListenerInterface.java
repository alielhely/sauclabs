package com.saucelabs.challenge.urlChecking;

public interface UrlListenerInterface extends Runnable {

	void process();
}
