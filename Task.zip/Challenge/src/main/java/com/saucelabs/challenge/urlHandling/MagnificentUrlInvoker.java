package com.saucelabs.challenge.urlHandling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MagnificentUrlInvoker implements UrlInvokerInterface {

	private static final int TIMEOUT = 15 * 1000;
	private static final String REQUEST_METHOD = "GET";

	public String getResponse(String urlString) {
		URL url = null;
		StringBuilder stringBuilder = null;
		try {
			url = new URL(urlString);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod(REQUEST_METHOD);
			// give to 15 seconds to respond
			connection.setReadTimeout(TIMEOUT);
			connection.connect();
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			stringBuilder = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				stringBuilder.append(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (stringBuilder != null)
			return stringBuilder.toString();
		return null;
	}
}
