package com.saucelabs.challenge.urlHandling;

public interface UrlInvokerInterface {

	public String getResponse(String url);

}
