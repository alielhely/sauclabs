/*
 * WireMockConfig.java
 *
 * Copyright © 2017 ING Group. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * ING Group ("Confidential Information").
 */
package nl.ing.rtpe.pan.ams.booking.service.configuration.mocks;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({WireMockProperties.class})
public class WireMockConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(WireMockConfig.class);
    private static final long PROCESS_STOP_TIMEOUT = 3000;

    private final WireMockProperties wireMockProps;

    private final Map<String, Process> standaloneWMServers = new HashMap<>();

    @Autowired
    public WireMockConfig(WireMockProperties wireMockProps) {
        this.wireMockProps = wireMockProps;
    }

    @PostConstruct()
    public void init() {
        LOGGER.debug("Initializing WireMock with properties: {}", wireMockProps);
        if (!wireMockProps.isEnabled()) return;

        File pathToJar = new File(wireMockProps.getWorkDir());

        // Loop over configuration entries
        for (WireMockProperties.WireMockServerProperties wmServerProps : wireMockProps.getServers())
        {
            // build command line
            List<String> cmd = new ArrayList<>();
            cmd.add("java");
            cmd.add("-jar");
            cmd.add(wireMockProps.getJarFileName());
            // Add command-line arguments
            wmServerProps.getCmdArgs().forEach((argKey, argValue) -> {
                cmd.add(argKey);
                cmd.add(argValue);
            });
            //TODO: add logging? " 2>> wiremockserver.error.log >> wiremockserver.output.log"
            String[] cmdArray = new String[cmd.size()];
            cmd.toArray(cmdArray);
            try {
                Process ps = Runtime.getRuntime().exec(cmdArray, null, pathToJar);
                standaloneWMServers.put(wmServerProps.getName(), ps);
            } catch (IOException e) {
                LOGGER.error("Error staring WireMockServer process", e);
            }
        }
    }

    @PreDestroy
    public void release() {
        LOGGER.info("Releasing WireMock resources");
        for (Entry<String, Process> entry : standaloneWMServers.entrySet()) {
            String serverName = entry.getKey();
            Process ps = entry.getValue();

            if (ps.isAlive()) {
                // Stop server gracefully
                LOGGER.info("Stopping WireMock server {}", serverName);
                ps.destroy(); // not really graceful... best alternative: call http://<host>:<port>/__admin/shutdown
                // Wait for process to shut down
                try {
                    ps.waitFor(PROCESS_STOP_TIMEOUT, TimeUnit.MILLISECONDS);
                } catch (InterruptedException e) {
                    LOGGER.debug("InterruptedException while waiting for WireMockServer process to stop", e);
                }
                // Destroy the process forcibly if still alive
                if (ps.isAlive()) {
                    LOGGER.debug("WireMock server {} is still alive. Destroy forcibly.", serverName);
                    ps.destroyForcibly();
                }
            }
        }
    }
}
