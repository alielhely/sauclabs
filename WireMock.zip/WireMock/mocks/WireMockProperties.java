/*
 * WireMockProperties.java
 *
 * Copyright © 2017 ING Group. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * ING Group ("Confidential Information").
 */
package nl.ing.rtpe.pan.ams.booking.service.configuration.mocks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Getter
@Setter
@ConfigurationProperties(prefix = "wiremock")
public class WireMockProperties {

    private boolean enabled = false;

    private String workDir = "./wiremock";
    private String jarFileName = "wiremock-standalone-2.17.0.jar";

    private List<WireMockServerProperties> servers = new ArrayList<>();

    @Getter
    @Setter
    public static class WireMockServerProperties {
        private String name = "WireMockServer";
        private Map<String, String> cmdArgs = new HashMap<>();
    }
}
